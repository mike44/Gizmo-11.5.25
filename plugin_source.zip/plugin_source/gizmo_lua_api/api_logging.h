/*
 *  api_logging.h
 *  Gizmo
 *
 *  Created by Ben Russell on 22/03/11.
 *  Copyright 2011 X-Plugins.com. All rights reserved.
 *
 */

int gizmo_builtin_logging_debug(lua_State *L);


